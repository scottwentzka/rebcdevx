/*
 * Copyright (c) 2019
 */
package com.rbc.firefly.core.etc;

import java.util.List;


/**
 * TODO: Document this
 */
public final class Firefly
{
	private Firefly() {}


	public static boolean bool(Object value)
	{
		return false;
	}


	public static RuntimeException abort(Throwable ex)
	{
		return new RuntimeException(ex);
	}


	public static RuntimeException abort(String message, IdentityValue... details)
	{
		return new RuntimeException(message);
	}


	public static IdentityValue iv(String ident, Object value)
	{
		return new IdentityValue(ident, value);
	}


	public static <A,B> Pair<A,B> pair(A a, B b)
	{
		return new Pair(a, b);
	}


	public static <T> T first(List<T> list)
	{
		return list.get(0);
	}


	public static <T> T second(List<T> list)
	{
		return list.get(1);
	}
}
