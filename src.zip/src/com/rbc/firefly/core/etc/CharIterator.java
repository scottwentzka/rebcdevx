/*
 * Copyright (c) 2019
 */
package com.rbc.firefly.core.etc;

import java.util.Iterator;


/**
 * An iterator for treating a string as a sequence of character objects that
 * can be iterated over. Useful mainly for ESC, since it has significant
 * execution overhead.
 */
public class CharIterator implements Iterator<Character>
{
	private final CharSequence string;
	private final int size;
	private int index;


	public CharIterator(CharSequence string)
	{
		this.string = string;
		this.size = string.length();
	}


	@Override
	public boolean hasNext()
	{
		return index < size;
	}
	

	@Override
	public Character next()
	{
		var ch = string.charAt(index);
		index ++;
		return ch;
	}
}
