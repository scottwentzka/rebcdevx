/*
 * Copyright (c) 2019
 */
package com.rbc.firefly.core.etc;

/**
 * TODO: Document this
 */
public class IdentityValue
{
	private final String ident;
	private final Object value;


	public IdentityValue(String ident, Object value)
	{
		this.ident = ident;
		this.value = value;
	}
}
