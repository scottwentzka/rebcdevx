/*
 * Copyright (c) 2019
 */
package com.rbc.firefly.core.etc;

/**
 * TODO: Document this
 */
public interface Identified
{
	/**
	 * Get the unique identity for this object within its scope. The value
	 * returned is never null nor empty and conforms to the definition of an
	 * identity.
	 */
	public String identity();
}
