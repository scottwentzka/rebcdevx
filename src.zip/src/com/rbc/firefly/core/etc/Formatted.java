/*
 * Copyright (c) 2019
 */
package com.rbc.firefly.core.etc;

/**
 * TODO: Document this
 */
public interface Formatted
{
	public String format();
}
