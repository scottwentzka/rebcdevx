/*
 * Copyright (c) 2019
 */
package com.rbc.firefly.core.etc;

/**
 * TODO: Document this
 */
public final class Characters
{
	private Characters() {}


	public static final char
		RETURN = '\r',
		NEWLINE = '\n',
		DOT = '.',
		OPEN = '(',
		CLOSE = ')',
		COLON = ':',
		DASH = '-',
		ESCAPE = '\\',
		TICK = '\'',
		STRING = '"',
		EOF = '\u0000';

	
	public static boolean ws(char ch)
	{
		return Character.isWhitespace(ch);
	}

	
	public static boolean letter(char ch)
	{
		return Character.isLetter(ch);
	}

	
	public static boolean digit(char ch)
	{
		return Character.isDigit(ch);
	}


	public static boolean in(char ch, String pattern)
	{
		return pattern.indexOf(ch) >= 0;
	}
}
