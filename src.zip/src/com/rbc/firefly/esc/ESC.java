/*
 * Copyright (c) 2019
 */
package com.rbc.firefly.esc;

import java.math.BigDecimal;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.Map;
import com.rbc.firefly.core.etc.CharIterator;
import com.rbc.firefly.esc.extend.Func1;
import com.rbc.firefly.esc.extend.Func2;
import static com.rbc.firefly.core.etc.Firefly.*;
import static java.math.BigDecimal.*;


/**
 * TODO: Document this
 */
public final class ESC
{
	private ESC() {}


	public static int int32(Object value)
	{
		if (value instanceof Integer)
		{
			return ((Integer)value).intValue();
		}
		return dec(value).intValue();
	}
	

	public static BigDecimal dec(Object value)
	{
		if (value == null)
		{
			/*
			 * It is easier to treat a null value as zero, since that creates
			 * less drama and likely does the "right thing" in most simple ESC
			 * expressions.
			 */
			return ZERO;
		}
		if (value instanceof BigDecimal)
		{
			return (BigDecimal)value;
		}
		if (value instanceof Number)
		{
			var n = (Number)value;
			if (n instanceof Float || n instanceof Double)
			{
				return BigDecimal.valueOf(n.doubleValue());
			}
			return BigDecimal.valueOf(n.longValue());
		}
		throw abort(
			"The value cannot be treated as a number, so this math operator " +
			"cannot be applied.",
			iv("value", value),
			iv("type", value.getClass()),
	}


	public static String string(Object value)
	{
		if (value == null)
		{
			throw abort(
				"A null value cannot be used as a string value for this " +
				"function.");
		}
		if (value instanceof String)
		{
			return (String)value;
		}
		throw abort("A string value is required for this function.",
			iv("value", value),
			iv("type", value.getClass()));
	}


	public static int CMP(Object a, Object b)
	{
		if (a == null)
		{
			return b == null ? 0 : -1;
		}
		if (b == null)
		{
			return 1;
		}
		var ac = a.getClass();
		var bc = b.getClass();
		if (ac != bc)
		{
			throw abort(
				"Cannot compare these two values because that are not " +
				"compatible types.",
				iv("a", ac),
				iv("b", bc));
		}
		if (a instanceof Comparable)
		{
			return ((Comparable)a).compareTo(b);
		}
		throw abort(
			"Cannot compare the two values since they do not implement t" +
			"he Java Comparable interface.",
			iv("a", ac),
			iv("b", bc));
	}

	
	public static boolean EQ(Object a, Object b)
	{
		if (a == null)
		{
			return b == null;
		}
		if (b == null)
		{
			return false;
		}
		return a.equals(b);
	}


	public static boolean LT(Object a, Object b)
	{
		return CMP(a, b) < 0;
	}


	public static boolean LTE(Object a, Object b)
	{
		return LT(a, b) || EQ(a, b);
	}


	public static boolean GT(Object a, Object b)
	{
		return CMP(a, b) > 0;
	}


	public static boolean GTE(Object a, Object b)
	{
		return GT(a, b) || EQ(a, b);
	}


	public static Iterator iterable(Object value)
	{
		if (value == null)
		{
			return Collections.EMPTY_LIST.iterator();
		}
		if (value instanceof Collection)
		{
			return ((Collection)value).iterator();
		}
		if (value instanceof CharSequence)
		{
			return new CharIterator((CharSequence)value);
		}
		if (value instanceof Map)
		{
			return ((Map)value).values().iterator();
		}
		throw abort(
			"The value cannot be used as a collection, string or sequence " +
			"of values.",
			iv("value", value),
			iv("type", value.getClass()));
	}

	
	public static Func1 func1(Object value)
	{
		FIXME
	}


	public static Func2 func2(Object value)
	{
		FIXME
	}


	public static RuntimeException mistyped(Object value, String context)
	{

	}
}
