/*
 * Copyright (c) 2019
 */
package com.rbc.firefly.esc;

import com.rbc.firefly.core.etc.Identified;


/**
 * TODO: Document this
 */
public final class Variable implements Identified
{
	private final String ident;
	private final int slot;


	public Variable(String ident, int slot)
	{
		this.ident = ident;
		this.slot = slot;
	}


	/**
	 * Get the unique identity for this object within its scope. The value
	 * returned is never null nor empty and conforms to the definition of an
	 * identity.
	 */
	@Override
	public String identity()
	{
		return ident;
	}


	public int slot()
	{
		return slot;
	}
	

	/**
	 * Return a representation of this object as text. The value returned is
	 * never null. This method is used strictly for diagnostic purposes, not
	 * for presentation to the user or as a canonical representation.
	 */
	public String toString()
	{
		return ident;
	}
}

