/*
 * Copyright (c) 2019
 */
package com.rbc.firefly.esc;

/**
 * TODO: Document this
 */
public class ESCException extends RuntimeException implements Source
{
	private Object src;
	private int line;
}
