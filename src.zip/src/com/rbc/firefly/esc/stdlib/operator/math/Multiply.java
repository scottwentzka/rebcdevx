/*
 * Copyright (c) 2019
 */
package com.rbc.firefly.esc.stdlib.operator.math;

import java.math.BigDecimal;


final class Multiply extends MathOperator
{
	/**
	 * Get the unique identity for this object within its scope. The value
	 * returned is never null nor empty and conforms to the definition of an
	 * identity.
	 */
	@Override
	public String identity()
	{
		return "*";
	}


	/**
	 * Apply this mathematical operator to the given two arguments. The
	 * arguments given are never null, but either or both can be any possible
	 * value, including zero.
	 */
	@Override
	protected BigDecimal apply(BigDecimal a, BigDecimal b)
	{
		return a.multiply(b, MC);
	}
}
