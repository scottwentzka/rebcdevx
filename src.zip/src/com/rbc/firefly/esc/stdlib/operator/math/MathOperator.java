/*
 * Copyright (c) 2019
 */
package com.rbc.firefly.esc.stdlib.operator.math;

import java.math.BigDecimal;
import java.math.MathContext;
import com.rbc.firefly.esc.ESCException;
import com.rbc.firefly.esc.extend.Operator;
import static com.rbc.firefly.esc.ESC.*;


/**
 * The base class for all mathematical operators. Since K9Z0 does very little
 * in the way of heavy-duy math, we simply do everything as BigDecimal. Crude,
 * but simple and adequate for the known problem domain (circa mid-2019).
 */
abstract class MathOperator implements Operator
{
	protected static final MathContext MC = MathContext.DECIMAL64;


	/**
	 * Apply this mathematical operator to the given two arguments. The
	 * arguments given are never null, but either or both can be any possible
	 * value, including zero.
	 */
	protected abstract BigDecimal apply(BigDecimal a, BigDecimal b);
	

	/**
	 * Apply this operator to the given two operands, returning the result.
	 * The operands may be of any type and may be null. The return value may
	 * be any type, including null.
	 */
	@Override
	public Object apply(Object a, Object b) throws ESCException
	{
		return apply(dec(a), dec(b));
	}
}
