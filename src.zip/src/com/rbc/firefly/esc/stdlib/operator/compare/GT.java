/*
 * Copyright (c) 2019
 */
package com.rbc.firefly.esc.stdlib.operator.compare;

import com.rbc.firefly.esc.ESC;
import com.rbc.firefly.esc.extend.Operator;


final class GT implements Operator
{
	/**
	 * Get the unique identity for this object within its scope. The value
	 * returned is never null nor empty and conforms to the definition of an
	 * identity.
	 */
	@Override
	public String identity()
	{
		return ">";
	}


	/**
	 * Apply this operator to the given two operands, returning the result.
	 * The operands may be of any type and may be null. The return value may
	 * be any type, including null.
	 */
	@Override
	public Object apply(Object a, Object b)
	{
		return ESC.GT(a, b);
	}
}
