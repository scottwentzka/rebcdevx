/*
 * Copyright (c) 2019
 */
package com.rbc.firefly.esc.stdlib.function.logic;

import com.rbc.firefly.esc.Environment;
import com.rbc.firefly.esc.extend.Func1;
import static com.rbc.firefly.core.etc.Firefly.*;


final class Not implements Func1
{
	/**
	 * Evaluate this function in the context of the given environment using
	 * the given argument. The argument given may be any type, including null.
	 * The return value may be any type, including null.
	 */
	@Override
	public Object eval(Environment env, Object a)
	{
		return ! bool(a);
	}
}
