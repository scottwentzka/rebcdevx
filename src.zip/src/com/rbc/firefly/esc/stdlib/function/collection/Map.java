/*
 * Copyright (c) 2019
 */
package com.rbc.firefly.esc.stdlib.function.collection;

import java.util.ArrayList;
import java.util.Collection;
import com.rbc.firefly.esc.ESC;
import com.rbc.firefly.esc.Environment;
import com.rbc.firefly.esc.extend.Func2;


/**
 * The classic 'map' function for applying a function to a sequence of values
 * and returning the collection of results.
 */
final class Map implements Func2
{
	/**
	 * Get the unique identity for this object within its scope. The value
	 * returned is never null nor empty and conforms to the definition of an
	 * identity.
	 */
	@Override
	public String identity()
	{
		return "map";
	}


	/**
	 * Evaluate this function in the context of the given environment using
	 * the given arguments. The arguments given may be any type, including null.
	 * The return value may be any type, including null.
	 */
	@Override
	public Object eval(Environment env, Object a, Object b)
	{
		if (a == null)
		{
			return null;
		}
		var fn = ESC.func1(b);
		if (a instanceof Collection)
		{
			var ac = (Collection)a;
			var list = new ArrayList(ac.size());
			for (var v : ((Collection)a))
			{
				list.add(fn.eval(env, v));
			}
			return list;
		}
		if (a instanceof CharSequence)
		{
			var as = (CharSequence)a;
			var sz = as.length();
			var list = new ArrayList(sz);
			for (var i = 0; i < sz; i++)
			{
				list.add(fn.eval(env, as.charAt(i)));
			}
			return list;
		}
		throw mistyped(a);
	}
}
