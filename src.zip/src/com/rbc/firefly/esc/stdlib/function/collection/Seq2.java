/*
 * Copyright (c) 2019
 */
package com.rbc.firefly.esc.stdlib.function.collection;

import java.util.List;
import com.rbc.firefly.esc.Environment;
import com.rbc.firefly.esc.extend.Func2;
import static com.rbc.firefly.core.etc.Firefly.*;


/**
 * The base class for any function with two arguments that can work with
 * sequences of values (strings or collections)
 */
abstract class Seq2 implements Func2
{
	/**
	 * Apply this function to the given value, which is never null. The
	 * second argument is never null, but no type checking has been performed.
	 * The value returned may be any type, including null.
	 */
	protected abstract Object string(String value, Object b);

	/**
	 * Apply this function to the given value, which is never null. The
	 * second argument is never null, but no type checking has been performed.
	 * The value returned may be any type, including null.
	 */
	protected abstract Object list(List value, Object b);


	/**
	 * Evaluate this function in the context of the given environment using
	 * the given arguments. The arguments given may be any type, including null.
	 * The return value may be any type, including null.
	 */
	@Override
	public Object eval(Environment env, Object a, Object b)
	{
		if (a == null)
		{
			return null;
		}
		if (a instanceof List)
		{
			return list((List)a, b);
		}
		if (a instanceof String)
		{
			return string((String)a, b);
		}
		throw abort(
			"The value is not any form of sequence, so the function cannot " +
			"be applied.",
			iv("type", a.getClass()));
	}
}
