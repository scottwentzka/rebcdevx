/*
 * Copyright (c) 2019
 */
package com.rbc.firefly.esc.stdlib.function.compare;

import com.rbc.firefly.esc.ESC;
import com.rbc.firefly.esc.Environment;
import com.rbc.firefly.esc.extend.FuncN;


final class Min implements FuncN
{
	/**
	 * Get the unique identity for this object within its scope. The value
	 * returned is never null nor empty and conforms to the definition of an
	 * identity.
	 */
	@Override
	public String identity()
	{
		return "min";
	}


	/**
	 * Evaluate this function in the context of the given environment using
	 * the given arguments. The arguments given may be any type, including null.
	 * The return value may be any type, including null.
	 */
	@Override
	public Object eval(Environment env, Object[] args)
	{
		var sz = args.length;
		if (sz == 0)
		{
			return null;
		}
		var min = args[0];
		for (var i = 1; i < sz; i++)
		{
			var b = args[i];
			min = ESC.LT(min, b) ? min : b;
		}
		return min;
	}
}
