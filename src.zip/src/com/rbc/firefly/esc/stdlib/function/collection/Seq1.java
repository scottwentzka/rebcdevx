/*
 * Copyright (c) 2019
 */
package com.rbc.firefly.esc.stdlib.function.collection;

import java.util.List;
import com.rbc.firefly.esc.Environment;
import com.rbc.firefly.esc.extend.Func1;
import static com.rbc.firefly.core.etc.Firefly.*;


/**
 * A base class for anything that can be treated like a sequence of values,
 * including a collection, list or a string.
 */
abstract class Seq1 implements Func1
{
	/**
	 * Apply this function to the given value, which is never null. The value
	 * returned may be any type, including null.
	 */
	protected abstract Object string(String value);

	/**
	 * Apply this function to the given value, which is never null. The value
	 * returned may be any type, including null.
	 */
	protected abstract Object list(List value);
	

	/**
	 * Evaluate this function in the context of the given environment using
	 * the given argument. The argument given may be any type, including null.
	 * The return value may be any type, including null.
	 */
	@Override
	public Object eval(Environment env, Object a)
	{
		if (a == null)
		{
			return null;
		}
		if (a instanceof List)
		{
			return list((List)a);
		}
		if (a instanceof String)
		{
			return string((String)a);
		}
		throw abort(
			"The value is not any form of sequence, so the function cannot " +
			"be applied.",
			iv("type", a.getClass()));
	}
}
