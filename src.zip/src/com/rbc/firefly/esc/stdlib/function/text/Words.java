/*
 * Copyright (c) 2019
 */
package com.rbc.firefly.esc.stdlib.function.text;

import com.rbc.firefly.esc.Environment;
import com.rbc.firefly.esc.extend.Func1;


final class Words implements Func1
{
	/**
	 * Get the unique identity for this object within its scope. The value
	 * returned is never null nor empty and conforms to the definition of an
	 * identity.
	 */
	@Override
	public String identity()
	{
		return "words";
	}


	/**
	 * Evaluate this function in the context of the given environment using
	 * the given argument. The argument given may be any type, including null.
	 * The return value may be any type, including null.
	 */
	@Override
	public Object eval(Environment env, Object a)
	{
		// FIXME: ESC, as below
//		return words(ESC.string(a));
		throw new RuntimeException("ESC FIX");
	}
}
