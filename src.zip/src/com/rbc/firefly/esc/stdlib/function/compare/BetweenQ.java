/*
 * Copyright (c) 2019
 */
package com.rbc.firefly.esc.stdlib.function.compare;

import com.rbc.firefly.esc.ESC;
import com.rbc.firefly.esc.Environment;
import com.rbc.firefly.esc.extend.Func3;


final class BetweenQ implements Func3
{
	/**
	 * Get the unique identity for this object within its scope. The value
	 * returned is never null nor empty and conforms to the definition of an
	 * identity.
	 */
	@Override
	public String identity()
	{
		return "between?";
	}


	/**
	 * Evaluate this function in the context of the given environment using
	 * the given arguments. The arguments given may be any type, including null.
	 * The return value may be any type, including null.
	 */
	@Override
	public Object eval(Environment env, Object a, Object b, Object c)
	{
		return ESC.GTE(a, b) && ESC.LTE(a, c);
	}
}
