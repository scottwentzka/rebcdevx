/*
 * Copyright (c) 2019
 */
package com.rbc.firefly.esc.stdlib.function.collection;

import java.util.ArrayList;
import com.rbc.firefly.esc.ESC;
import com.rbc.firefly.esc.Environment;
import com.rbc.firefly.esc.extend.Func2;
import static com.rbc.firefly.core.etc.Firefly.*;


final class Reject implements Func2
{
	/**
	 * Get the unique identity for this object within its scope. The value
	 * returned is never null nor empty and conforms to the definition of an
	 * identity.
	 */
	@Override
	public String identity()
	{
		return "reject";
	}


	/**
	 * Evaluate this function in the context of the given environment using
	 * the given arguments. The arguments given may be any type, including null.
	 * The return value may be any type, including null.
	 */
	@Override
	public Object eval(Environment env, Object a, Object b)
	{
		var i = ESC.iterable(a);
		var fn = ESC.func1(b);
		var selected = new ArrayList<Object>();
		while(i.hasNext())
		{
			var v = i.next();
			if (! bool(fn.eval(env, v)))
			{
				selected.add(v);
			}
		}
		return selected;
	}
}
