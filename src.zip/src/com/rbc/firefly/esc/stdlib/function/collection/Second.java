/*
 * Copyright (c) 2019
 */
package com.rbc.firefly.esc.stdlib.function.collection;

import java.util.List;


final class Second extends Seq1
{
	/**
	 * Get the unique identity for this object within its scope. The value
	 * returned is never null nor empty and conforms to the definition of an
	 * identity.
	 */
	@Override
	public String identity()
	{
		return "second";
	}


	/**
	 * Apply this function to the given value, which is never null. The value
	 * returned may be any type, including null.
	 */
	@Override
	protected Object string(String value)
	{
		return value.length() > 1 ? value.charAt(1) : null;
	}


	/**
	 * Apply this function to the given value, which is never null. The value
	 * returned may be any type, including null.
	 */
	@Override
	protected Object list(List value)
	{
		return value.size() > 1 ? value.get(1) : null;
	}
}
