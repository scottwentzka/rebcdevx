/*
 * Copyright (c) 2019
 */
package com.rbc.firefly.esc.stdlib.function.collection;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;


final class Rest extends Seq1
{
	/**
	 * Get the unique identity for this object within its scope. The value
	 * returned is never null nor empty and conforms to the definition of an
	 * identity.
	 */
	@Override
	public String identity()
	{
		return "rest";
	}


	/**
	 * Apply this function to the given value, which is never null. The value
	 * returned may be any type, including null.
	 */
	@Override
	protected Object string(String value)
	{
		if (value.length() < 2)
		{
			return "";
		}
		return value.substring(1);
	}


	/**
	 * Apply this function to the given value, which is never null. The value
	 * returned may be any type, including null.
	 */
	@Override
	protected Object list(List value)
	{
		var sz = value.size();
		if (sz < 2)
		{
			return Collections.EMPTY_LIST;
		}
		var list = new ArrayList(sz - 1);
		for (var i = 1; i < sz; i++)
		{
			list.add(value.get(i));
		}
		return list;
	}
}
