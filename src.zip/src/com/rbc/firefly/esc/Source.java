/*
 * Copyright (c) 2019
 */
package com.rbc.firefly.esc;

/**
 * TODO: Document this
 */
public interface Source
{
}
