/*
 * Copyright (c) 2019
 */
package com.rbc.firefly.esc;

/**
 * TODO: Document this
 */
public class Environment
{
	public void set(Variable v, Object value)
	{
		FIXME
	}

	
	public void reset(Variable... vars)
	{
		FIXME
	}
}
