/*
 * Copyright (c) 2019
 */
package com.rbc.firefly.esc.ast.call;

import com.rbc.firefly.esc.Environment;
import com.rbc.firefly.esc.ast.Node;
import com.rbc.firefly.esc.extend.Func2;


public final class Call2 extends Node
{
	private final Node a;
	private final Node b;
	private final Func2 func;


	public Call2(Node a, Node b, Func2 func)
	{
		this.a = a;
		this.b = b;
		this.func = func;
	}


	/**
	 * Evaluate this AST node in the context of the given environment. The
	 * value returned may be anything, including null.
	 */
	@Override
	public Object eval(Environment env)
	{
		return func.eval(env, a.eval(env), b.eval(env));
	}
}

