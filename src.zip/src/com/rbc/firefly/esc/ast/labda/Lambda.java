/*
 * Copyright (c) 2019
 */
package com.rbc.firefly.esc.ast.labda;

import com.rbc.firefly.esc.Environment;
import com.rbc.firefly.esc.ast.Node;
import com.rbc.firefly.esc.extend.Func;


/**
 * TODO: Document this
 */
public abstract class Lambda extends Node implements Func
{
	/**
	 * Evaluate this AST node in the context of the given environment. The
	 * value returned may be anything, including null.
	 */
	@Override
	public Object eval(Environment env)
	{
		return this;
	}
}
