/*
 * Copyright (c) 2019
 */
package com.rbc.firefly.esc.ast.labda;

import com.rbc.firefly.esc.Environment;
import com.rbc.firefly.esc.Variable;
import com.rbc.firefly.esc.ast.Node;
import com.rbc.firefly.esc.extend.Func2;


/**
 * An anonymous function with two arguments. 
 */
public final class Lambda2 implements Func2
{
	private final Variable av;
	private final Variable bv;
	private final Node body;


	public Lambda2(Variable av, Variable bv, Node body)
	{
		this.av = av;
		this.bv = bv;
		this.body = body;
	}


	/**
	 * Evaluate this function in the context of the given environment using
	 * the given arguments. The arguments given may be any type, including null.
	 * The return value may be any type, including null.
	 */
	@Override
	public Object eval(Environment env, Object a, Object b)
	{
		env.set(av, a);
		env.set(bv, b);
		var r = body.eval(env);
		env.reset(av, bv);
		return r;
	}
}
