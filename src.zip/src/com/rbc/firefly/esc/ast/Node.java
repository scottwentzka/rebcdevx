/*
 * Copyright (c) 2019
 */
package com.rbc.firefly.esc.ast;

import java.util.List;
import com.rbc.firefly.esc.Environment;


/**
 * TODO: Document this
 */
public abstract class Node
{
	protected Node[] array(List<Node> args)
	{
		return args.toArray(new Node[0]);
	}

	
	/**
	 * Evaluate this AST node in the context of the given environment. The
	 * value returned may be anything, including null.
	 */
	public abstract Object eval(Environment env);
}
