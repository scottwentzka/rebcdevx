/*
 * Copyright (c) 2019
 */
package com.rbc.firefly.esc.ast.special;

import java.util.List;
import com.rbc.firefly.esc.Environment;
import com.rbc.firefly.esc.ast.Node;
import static com.rbc.firefly.core.etc.Firefly.*;


/**
 * the (or) special form in ESC. The (or) must be a special form, and not
 * a function since we must support short-circuit evaluation. Yes, a true
 * Clojure clone would have this as a macro, and therefore not need it as a
 * special form. But, try explaining symbol hygiene and macro expansion to
 * someone, and you will end up making it a special form, too.
 */
public class Or extends Node
{
	private final Node[] args;


	public Or(List<Node> args)
	{
		this.args = array(args);
	}


	/**
	 * Evaluate this AST node in the context of the given environment. The
	 * value returned may be anything, including null.
	 */
	@Override
	public Object eval(Environment env)
	{
		for (var arg : args)
		{
			if (bool(arg.eval(env)))
			{
				return true;
			}
		}
		return false;
	}
}
