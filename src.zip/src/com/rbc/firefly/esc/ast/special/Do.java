/*
 * Copyright (c) 2019
 */
package com.rbc.firefly.esc.ast.special;

import java.util.List;
import com.rbc.firefly.esc.Environment;
import com.rbc.firefly.esc.ast.Node;


/**
 * The (do) special form.
 */
public class Do extends Node
{
	private final Node[] nodes;


	public Do(List<Node> nodes)
	{
		this.nodes = array(nodes);
	}


	/**
	 * Evaluate this AST node in the context of the given environment. The
	 * value returned may be anything, including null.
	 */
	@Override
	public Object eval(Environment env)
	{
		Object r = null;
		for (var node : nodes)
		{
			r = node.eval(env);
		}
		return r;
	}
}
