/*
 * Copyright (c) 2019
 */
package com.rbc.firefly.esc.ast.special;

import java.util.List;
import com.rbc.firefly.core.etc.Pair;
import com.rbc.firefly.esc.Environment;
import com.rbc.firefly.esc.ast.Node;
import static com.rbc.firefly.core.etc.Firefly.*;


/**
 * The (cond) special form is the ESC version of the Java switch construct and
 * is identical to the classic Lisp/Clojure (cond) special form. For example:
 *
 * 		(cond
 * 			(a > b)	"bigger"
 * 			(a < b) "smaller"
 * 			true	"same")
 *
 * Admittedly not the easiest form to read when it gets large, but it is
 * following its Clojure model. Note that the number of arguments must always
 * be an even number.
 */
public class Cond extends Node
{
	private final Pair<Node,Node>[] cases;


	public Cond(List<Node> args)
	{
		var sz = args.size();
		var pairs = sz / 2;
		if ((sz % 2) != 0)
		{
			throw abort(
				"The number of arguments to the (cond) special form must " +
				"always be an even number, since they must form " +
				"condition/expression pairs.");
		}

		this.cases = new Pair[pairs];
		var p = 0;
		for (var i = 0; i < sz; i += 2)
		{
			cases[p] = pair(args.get(i), args.get(i + 1));
			p++;
		}
	}


	/**
	 * Evaluate this AST node in the context of the given environment. The
	 * value returned may be anything, including null.
	 */
	@Override
	public Object eval(Environment env)
	{
		for (var c : cases)
		{
			if (bool(c.a().eval(env)))
			{
				return c.b().eval(env);
			}
		}
		return null;
	}
}
