/*
 * Copyright (c) 2019
 */
package com.rbc.firefly.esc.ast.special;

import com.rbc.firefly.esc.Environment;
import com.rbc.firefly.esc.ast.Node;


/**
 * The ESC node supporting memoization. This allows for the cost of evaluation
 * of an expression to be paid only once. This is not full functional
 * memoization, which is not practical in Java (since arguments are not
 * immutable and therefore pure memoization of an arbitrary function is not
 * possible).
 */
public class Memoize extends Node
{
	private static final Object UNDEFINED = new Object();
	
	private final Node expr;
	private transient Object value;


	public Memoize(Node expr)
	{
		this.expr = expr;
		this.value = UNDEFINED;
	}


	/**
	 * Evaluate this AST node in the context of the given environment. The
	 * value returned may be anything, including null.
	 */
	@Override
	public Object eval(Environment env)
	{
		if (value == UNDEFINED)
		{
			synchronized (expr)
			{
				value = expr.eval(env);
			}
		}
		return value;
	}
}
