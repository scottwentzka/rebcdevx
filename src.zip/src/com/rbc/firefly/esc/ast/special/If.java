/*
 * Copyright (c) 2019
 */
package com.rbc.firefly.esc.ast.special;

import java.util.List;
import com.rbc.firefly.esc.Environment;
import com.rbc.firefly.esc.ast.Node;
import static com.rbc.firefly.core.etc.Firefly.*;


/**
 * The (if) special form in ESC. This support short-circuit evaluation and
 * the optional false path.
 */
public final class If extends Node
{
	private final Node cond;
	private final Node t;
	private final Node f;


	public If(List<Node> args)
	{
		this.cond = first(args);
		this.t = second(args);
		this.f = args.size() == 2 ? null : args.get(2);
	}


	/**
	 * Evaluate this AST node in the context of the given environment. The
	 * value returned may be anything, including null.
	 */
	@Override
	public Object eval(Environment env)
	{
		if (bool(cond.eval(env)))
		{
			return t.eval(env);
		}
		return f == null ? null : f.eval(env);
	}
}
