/*
 * Copyright (c) 2019
 */
package com.rbc.firefly.esc.extend;

import com.rbc.firefly.core.etc.Identified;
import com.rbc.firefly.esc.ESCException;


/**
 * TODO: Document this
 */
public interface Operator implements Identified
	// FIXME , Named, Described
{
	/**
	 * Apply this operator to the given two operands, returning the result.
	 * The operands may be of any type and may be null. The return value may
	 * be any type, including null.
	 */
	public Object apply(Object a, Object b);
}
