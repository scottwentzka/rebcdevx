/*
 * Copyright (c) 2019
 */
package com.rbc.firefly.esc.extend;

import com.rbc.firefly.core.etc.Identified;
import static com.rbc.firefly.core.etc.Firefly.*;


/**
 * TODO: Document this
 */
public interface Func  extends Identified // FIXME: Named, Described
{
	/**
	 * A convenience function used by function implementations when an argument
	 * is not of the correct type.
	 */
	public default RuntimeException mistyped(Object value)
	{
		return abort("A value of this type cannot be used with this function.",
			iv("function", identity()),
			iv("value", value),
			iv("type", value.getClass()));
	}

	
	// FIXME: Put this back in
//	private Cardinality arguments();
}
