/*
 * Copyright (c) 2019
 */
package com.rbc.firefly.esc.extend;

import com.rbc.firefly.esc.Environment;


/**
 * TODO: Document this
 */
public interface Func2 extends Func
{
	/**
	 * Evaluate this function in the context of the given environment using
	 * the given arguments. The arguments given may be any type, including null.
	 * The return value may be any type, including null.
	 */
	public Object eval(Environment env, Object a, Object b);
}
