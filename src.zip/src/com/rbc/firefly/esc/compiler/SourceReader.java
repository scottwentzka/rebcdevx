/*
 * Copyright
 */
package com.rbc.firefly.esc.compiler;

import java.io.IOException;
import java.io.Reader;
import static com.rbc.firefly.core.etc.Characters.*;
import static com.rbc.firefly.core.etc.Firefly.*;


/**
 * A class for reading source code from an input stream. This ignores any
 * ASCII CR characters, provides for pushback, and returns an EOF character
 * when the end of the stream has been read.
 */
final class SourceReader
{
	private final Reader in;
	private final int unit;
	private int line;
	private char pushed;


	public SourceReader(Reader in, int unit)
	{
		this.in = in;
		this.unit = unit;
		this.line = 1;
	}


	/**
	 * Get the next character read. Tabs are expanded and transformed into a
	 * single space, and return characters are simply discarded.
	 */
	public char next()
	{
		if (pushed != EOF)
		{
			var ch = pushed;
			pushed = EOF;
			return ch;
		}
		try
		{
			while(true)
			{
				int i = in.read();
				if (i < 0)
				{
					return EOF;
				}
				char ch = (char)i;
				switch(ch)
				{
					case RETURN:
						break;

					case NEWLINE:
						line ++;
						return ch;

					default:
						return ch;
				}
			}
		}
		catch (IOException e)
		{
			throw abort(e);
		}
	}


	public void push(char ch)
	{
		if (pushed != EOF)
		{
			throw abort("A character was already pushed.",
				iv("pushed", pushed),
				iv("ch", ch));
		}
		pushed = ch;
	}


	/**
	 * Get the unique ID of the compilation unit. The compilation unit can
	 * be traced back to the actual source code via a reverse lookup.
	 */
	public int unit()
	{
		return unit;
	}


	/**
	 * Get the line within the compilation unit. The line returned is one
	 * based, not zero based. That is, the first line is one. The special
	 * NONE is returned if there is no line.
	 */
	public int line()
	{
		return line;
	}


	/**
	 * Closes this reader, relinquishing any underlying resources.
	 */
	public void close()
	{
		try
		{
			in.close();
		}
		catch (IOException e)
		{
			throw abort(e);
		}
	}
}
