/*
 * Copyright (c) 2019
 */
package com.rbc.firefly.esc.compiler;

/**
 * An interface for any object that can relate back to the exact location
 * within ESC code.
 */
public interface Source
{
	public static final int NONE = 0;

	/**
	 * Get the line within the compilation unit. The line returned is one
	 * based, not zero based. That is, the first line is one. The special
	 * NONE is returned if there is no line.
	 */
	public int line();
}
