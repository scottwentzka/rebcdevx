/*
 * Copyright (c) 2019
 */
package com.rbc.firefly.esc.compiler;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import com.rbc.firefly.core.etc.IdentityValue;
import com.rbc.firefly.esc.compiler.Token.Kind;
import static com.rbc.firefly.core.etc.Characters.*;
import static com.rbc.firefly.core.etc.Firefly.*;


/**
 * A lexical analyzer for the ESC grammar.
 */
public class Lexer
{
	private static final char
		COMMENT = ';';

	private static final String OPERATORS = "+-*/?<>=!%";

	private static final Map<String,Object> KEYWORDS = new HashMap<>();
	static
	{
		KEYWORDS.put("true", Boolean.TRUE);
		KEYWORDS.put("false", Boolean.FALSE);
		KEYWORDS.put("nil", null);
	}
	
	private final SourceReader in;
	private final StringBuilder buffer;
	private Token pushed;


	public Lexer(SourceReader in)
	{
		this.in = in;
		this.buffer = new StringBuilder(100);
	}


	public Token next()
	{
		while(true)
		{
			var ch = in.next();
			switch(ch)
			{
				case OPEN:		return token(Kind.OPEN);
				case CLOSE:		return token(Kind.CLOSE);
				case DASH:		return dash();
				case COLON:		return colon();
				case ESCAPE:	return character();
				case STRING:	return string(STRING);
				case TICK:		return string(TICK);
				case COMMENT:	comments(); break;
				default:
					if (! ws(ch))
					{
						if (letter(ch))
						{
							return ambiguous(ch);
						}
						if (digit(ch))
						{
							return number(ch);
						}
						if (in(ch, OPERATORS))
						{
							return operator(ch);
						}
					}
			}
		}
	}


	/**
	 * The ";" comment indicator has been encountered, so we simply discard
	 * any characters between here and the end of the line.
	 */
	private void comments()
	{
		while (true)
		{
			var ch = in.next();
			if (ch == EOF || ch == NEWLINE)
			{
				return;
			}
		}
	}
	

	/**
	 * A dash has been encountered, which may be a negative number or a
	 * subtraction operator, or something else.
	 */
	private Token dash()
	{
		var ch = in.next();
		if (digit(ch))
		{
			return number(ch);
		}
		if (in(ch, OPERATORS))
		{
			buf(DASH);
			return operator(ch);
		}
		in.push(ch);
		return token(Kind.OPERATOR, "-");
	}


	/**
	 * Process the given first character, and any subsequent characters, as
	 * an operator.
	 */
	private Token operator(char first)
	{
		buf(first);
		while(true)
		{
			var ch = in.next();
			if (in(ch, OPERATORS))
			{
				buf(ch);
			}
			else
			{
				in.push(ch);
				return token(Kind.OPERATOR, buf());
			}
		}
	}


	/**
	 * The color character indicates we are dealing with a type of some sort.
	 * The value is one of the following:
	 *
	 * 		:type
	 * 		:type.enum
	 *
	 * 	Resolution of the type occurs at compile time. This works for both
	 * 	enum values as well as RDM values.
	 */
	private Token colon()
	{
		while(true)
		{
			var ch = in.next();
			if (identifier(ch))
			{
				buf(ch);
			}
			else
			{
				if (ch == DOT)
				{
					var ident = buf();
					var type = TypesZ.instance().find(ident);
					if (type == null)
					{
						throw error(
							"That is not any known type.",
							iv("type", ident));
					}
					return enums(type);
				}
				in.push(ch);
				var ident = buf();
				var type = TypesZ.instance().find(ident);
				if (type == null)
				{
					throw error(
						"That is not any known type.",
						iv("type", ident));
				}
				return token(Kind.LITERAL, type);
			}
		}
	}


	private Token enums(TypeZ type)
	{
		while(true)
		{
			var ch = in.next();
			if (identifier(ch))
			{
				buf(ch);
			}
			else
			{
				in.push(ch);
				var ident = buf();
				if (isa(type.actual(), Enum.class))
				{
					var e = Enums.find(type.actual(), ident);
					if (e == null)
					{
						throw error(
							"The given value is not one of the enumerated " +
							"type values defined.",
							iv("type", type),
							iv("value", ident));
					}
					return token(Kind.LITERAL, e);
				}
				if (isa(type.actual(), ReferenceValue.class))
				{
					var refs = ReferenceValues.of(type.actual());
					var r = refs.find(ident);
					if (r == null)
					{
						throw error(
							"The given value is not one of the defined RDM " +
							"values for this type.",
							iv("type", type),
							iv("value", ident));
					}
					return token(Kind.LITERAL, r);
				}
				throw error(
					"The type is not an enumerated type nor an RDM reference " +
					"value, so the value cannot be looked up..",
					iv("type", type),
					iv("value", ident));
			}
		}
	}


	private Token character()
	{
		FIXME
	}


	private Token string(char delimiter)
	{
		FIXME
	}


	private Token number(char ch)
	{
		FIXME
	}


	private Token ambiguous(char ch)
	{
		buf(ch);
		while(true)
		{
			ch = in.next();
			if (identifier(ch))
			{
				buf(ch);
			}
			else
			{
				if (ch == DOT)
				{
					return nav(buf());
				}
				in.push(ch);

				/*
				 * At this point, we have reached the end of the identifier
				 * and it is not a navigation path. So, we attempt to figure
				 * out exactly what it might be.
				 */
				var ident = buf();
				var keyword = KEYWORDS.get(ident);
				if (keyword == null)
				{
					return token(Kind.IDENTIFIER, ident);
				}
				return token(Kind.LITERAL, keyword.value());
			}
		}
	}


	/**
	 * In this case, the sequence of characters has been identified as an
	 * access path, and the given word is the first part.
	 */
	private Token path(String word)
	{
		var parts = new ArrayList<String>(4);
		parts.add(word);
		var first = true;
		while(true)
		{
			var ch = in.next();
			if (ch == DOT)
			{
				parts.add(content());
				first = true;
			}
			else
			{
				if (first)
				{
					if (initial(ch))
					{
						buf(ch);
						first = false;
					}
					else
					{
						in.push(ch);
						parts.add(content());
						return token(Kind.PATH, parts);
					}
				}
				else
				{
					if (identifier(ch))
					{
						buf(ch);
					}
					else
					{
						in.push(ch);
						parts.add(content());
						return token(Kind.PATH, parts);
					}
				}
			}
		}
	}

	
	/**
	 * At this point, we have read the first element of a navigation path and
	 * a dot character. So, we now read the rest of the path.
	 */
	private Token nav(String root)
	{
		FIXME
	}


	/**
	 * A string indicator has been encountered, which means either a simple
	 * string or a multi-line string. Note that we support both tick and double
	 * quote as string indicators.
	 */
	private Token string()
	{
		var begin = in.line();
		while(true)
		{
			var ch = in.next();
			switch(ch)
			{
				case ESCAPE:
					buf(escape());
					break;

				case TAB:
					if (last() != SPACE)
					{
						buf(SPACE);
					}
					break;

				case NEWLINE:
					/*
					 * In this case, we have encountered a newline, which
					 * indicates a multi-line string. So, we get rid of any
					 * trailing whitespace, add a single space, and then
					 * skip all characters until we reach a non-whitespace
					 * character or the string terminator.
					 */
					trim();
					buf(SPACE);
					var end = false;
					while(! end)
					{
						ch = in.next();
						if (ch == EOF)
						{
							throw error(
								"Unexpected EOF within a string literal. " +
								"The string begins on line " + begin + '.');
						}
						if (! ws(ch))
						{
							in.push(ch);
							end = true;
						}
					}
					break;

				case STRING:
					return token(Kind.LITERAL, Str.of(buf()));

				case EOF:
					throw error(
						"Unexpected EOF within a string literal. " +
						"The string begins on line " + begin + '.');

				default:
					buf(ch);
			}
		}
	}


	/**
	 * Trim trailing whitespace from the buffer, if any.
	 */
	private void trim()
	{
		var i = buffer.length() - 1;
		while (i >= 0)
		{
			var ch = buffer.charAt(i);
			if (! ws(ch))
			{
				buffer.setLength(i + 1);
			}
			i --;
		}
		buffer.setLength(0);
	}



	private Token token(Kind kind)
	{
		return new Token(kind, in.line(), null);
	}


	private Token token(Kind kind, Object value)
	{
		return new Token(kind, in.line(), value);
	}



	private boolean identifier(char ch)
	{
		return initial(ch) || digit(ch) || ch == DASH || ch == '?';
	}


	private boolean initial(char ch)
	{
		return letter(ch);
	}


	private void buf(char ch)
	{
		buffer.append(ch);
	}


	private String buf()
	{
		var s = buffer.toString();
		buffer.setLength(0);
		return s;
	}


	private RuntimeException error(String message, IdentityValue... details)
	{
		FIXME
	}
}
