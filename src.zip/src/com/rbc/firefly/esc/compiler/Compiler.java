/*
 * Copyright (c) 2019
 */
package com.rbc.firefly.esc.compiler;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.rbc.firefly.esc.ast.Node;
import com.rbc.firefly.esc.ast.special.*;
import com.rbc.firefly.esc.compiler.Token.Kind;
import com.rbc.firefly.esc.extend.Func;
import com.rbc.firefly.esc.extend.Operator;
import static com.rbc.firefly.core.etc.Firefly.*;
import static com.rbc.firefly.esc.compiler.Token.Kind.*;


/**
 * TODO: Document this
 */
public class Compiler
{
	/**
	 * All of the following are special forms in ESC, since they cannot be
	 * represented as functions. Each has distinct behavior for either the
	 * compiler or the ESC runtime.
	 */
	public enum Special
	{
		LET(3, 3),
		IF(2, 3),
		COND(3, Cardinality.INFINITY),
		FN(2, Cadinality.INFINITY),
		MEMOIZE(1, 1),
		AND(2, Cardinality.INFINITY),
		OR(2, Cardinality.INFINITY);

		private final Cardinality args;

		private Special(int min, int max)
		{
			this.args = Cardinality.of(min, max);
		}

		public Cardinality args() { return args; }
	}

	private static final Map<String,Special>  SPECIAL = new HashMap<>();
	static
	{
		for (var s : Special.values())
		{
			SPECIAL.put(lower(s.name()), s);
		}
	}

	private static final IdentityMap<Func> FUNCTIONS = new IdentityMap<>();
	static
	{
		for (var module : App.instance().modules())
		{
			var res = module.find("esc/functions.cfg");
			if (res != null)
			{
				for (var entry : res.entries())
				{
					var func = Reflection.construct(Func.class, entry);
					FUNCTIONS.put(func);
				}
			}
		}
	}

	private static final IdentityMap<Operator> OPERATORS = new IdentityMap<>();
	static
	{
		for (var module : App.instance().modules())
		{
			var res = module.find("esc/operators.cfg");
			if (res != null)
			{
				for (var entry : res.entries())
				{
					var func = Reflection.construct(Operator.class, entry);
					FUNCTIONS.put(func);
				}
			}
		}
	}

	private Lexer lex;
	private Token pushed;


	/**
	 * Parse the next expression from the source input stream. A non-null
	 * value is returned, or an exception is thrown.
	 */
	private Node expr()
	{
		var token = next();
		switch(token.kind())
		{
			case OPEN:	return open();
			
			case EOF:
				throw error(token,
					"Expecting expression, but encountered the EOF instead.");
				
			default:
				throw syntax(token);
		}
	}


	private Node open()
	{
		var token = next();
		if (token.is(IDENTIFIER))
		{
			var spec = SPECIAL.get(token.string());
			if (spec == null)
			{
				var func = FUNCTIONS.find(token.string());
				if (func == null)
				{
					PUKE
				}
				return func(token, func);
			}
			return special(token, spec);
		}
		else
		{
			PUKE
		}
	}


	private Node func(Token start, Func func)
	{
		while(true)
		{
			var token = next();
			if (token.is(Kind.CLOSE))
			{

			}
		}
		FIXME
	}


	private Node special(Token token, Special spec)
	{
		switch(spec)
		{
			case IF:		return new If(args(spec));
			case COND:		return new Cond(arg(spec));
			case FN:		return fn(token);
			case LET:		return let(token);
			case MEMOIZE:	return new Memoize(first(args(spec)));
			case AND:		return new And(args(spec));
			case OR:		return new Or(args(spec));
			default:
				throw impossible(spec);
		}
	}


	/**
	 * The (fn) special for for an anonymous function. This takes the form
	 * of either:
	 *
	 * 		(fn x (x > 5))
	 * 		(fn (a b) (compare a b))
	 *
	 * We support a simplified shorthand for single-argument functions (of
	 * which there are quite a few).
	 */
	private Node fn(Token begin)
	{
		var params = params();
	}


	/**
	 * Get the number of 
	 */
	private Node let(Token begin)
	{
		FIXME
	}


	/**
	 * Get the number of arguments to a function definition. This supports
	 * all of the following forms:
	 *
	 * 		x
	 * 		(x y)
	 *
	 * That is, it supports the classic Lisp style (which is more orthogonal).
	 * Note that this also make checks to ensure parameters are not shadowing
	 * something else already in scope.
	 */
	private List<String> params()
	{
		var token = next();
		switch(token.kind())
		{
			case IDENTIFIER:
				return pair(token.string(), expr());

			case OPEN:
				// (x y)

			default:
				throw error(token,
					"Expecting either an identifier for a single-argument " +
					"or an open parenthesis indicating a multiple arguments.",
					iv("unexpected", token));
		}
	}

	
	private List<Node> args(Special spec)
	{
		var args = args();
		if (! spec.args().bounds(args))
		{
			PUKE // Wrong number of arguments for this special form.
		}
		return args;
	}


	/**
	 * Collect the arguments to a function or special form. We do not place
	 * any interpretation on them, only collect them. The list returned may
	 * be empty if there are no arguments.
	 */
	private List<Node> args()
	{
		var list = new ArrayList<Node>();
		while(true)
		{
			var token = next();
			if (token.is(Kind.CLOSE))
			{
				return list;
			}
			else
			{
				push(token);
				list.add(expr());
			}
		}
	}


	/**
	 * Read the next token via this lexical analyzer. The value returned is
	 * never null, but a token with the kind of EOF is returned when the
	 * end of the input stream has been reached.
	 */
	public Token next()
	{
		if (pushed != null)
		{
			var token = pushed;
			pushed = null;
			return token;
		}
		return lex.next();
	}


	/**
	 * Push back the last token returned from next(). Only a single level of
	 * pushback is supported.
	 */
	public void push(Token token)
	{
		if (pushed != null)
		{
			throw abort("A token has already been pushed.",
				iv("pushed", pushed),
				iv("token", token));
		}
		pushed = token;
	}

}
