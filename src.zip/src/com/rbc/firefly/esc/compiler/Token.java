/*
 * Copyright (c) 2019
 */
package com.rbc.firefly.esc.compiler;

import static com.rbc.firefly.core.etc.Characters.*;


/**
 * A token in the ESC language.
 */
final class Token implements Source
{
	public enum Kind
	{
		OPEN,
		CLOSE,
		IDENTIFIER,
		OPERATOR,
		LITERAL,
		PATH,
		TYPE,
		ENUM,
		EOF
	}

	/**
	 * All of the following are special forms in ESC, since they cannot be
	 * represented as functions. Each has distinct behavior for either the
	 * compiler or the ESC runtime.
	 */
	public enum Special
	{
		LET,
		IF,
		COND,
		FN,
		MEMOIZE,
		AND,
		OR
	}

	private final int line;
	private final Kind kind;
	private final Object value;


	public Token(Kind kind, int line, Object value)
	{
		this.line = line;
		this.kind = kind;
		this.value = value;
	}


	public Kind kind()	{ return kind; }

	public boolean is(Kind kind)
	{
		return this.kind == kind;
	}


	/**
	 * Get the line within the compilation unit. The line returned is one
	 * based, not zero based. That is, the first line is one. The special
	 * NONE is returned if there is no line.
	 */
	@Override
	public int line()
	{
		return line;
	}
	

	public Object value()
	{
		return value;
	}

	
	/**
	 * Provide a friendly, human-readable text snippet for this token. This
	 * is intended to be used in the generation of friendly error messages.
	 */
	public String explain()
	{
		switch(kind)
		{
			case KEYWORD:
				return "the keyword '" + keyword().keyword() + TICK;

			case IDENTIFIER:
				return "the identifier '" + string() + TICK;

			case OPERATOR:
				return "the '" + operator().keyword() + TICK;

			case PARAMETER:
				return "the parameter '" + string() + TICK;

			case MACRO:
				return "the macro '-" + string() + TICK;

			default:
				return kind.explain();
		}
	}


	/**
	 * Return a representation of this object as text. The value returned is
	 * never null. This method is used strictly for diagnostic purposes, not
	 * for presentation to the user or as a canonical representation.
	 */
	public String toString()
	{
		return kind.name();
	}
}
