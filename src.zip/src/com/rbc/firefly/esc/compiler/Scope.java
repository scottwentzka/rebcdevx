/*
 * Copyright (c) 2019
 */
package com.rbc.firefly.esc.compiler;

/**
 * An object representing the current local variables that are in scope for
 * an expression. Since ESC is designed for simple expressions, we do not bother
 * with nesting scopes and just keep a single global scope of the current
 * values contained in it.
 */
public class Scope
{
}
